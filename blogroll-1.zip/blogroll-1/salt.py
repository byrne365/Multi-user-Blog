# Implement the hash_str function to use HMAC
# and our SECRET instead of md5
SECRET = 'nobodyknowsthetroubleihaveseen'
# placed here so that its not published
